var app = angular.module("VehicleManagement", []);
 
// Controller Part
app.controller("VehicleController", function($scope, $http) {
 
 
    $scope.vehicles = [];
    $scope.vehicleForm = {
    		mfrId: 1,
    		mfrName: "",
    		city: "",
    		state: "",
    		country: ""
    };
 
    // Now load the data from server
    _refreshVehicleData();
 
    // HTTP POST/PUT methods for add/edit vehicle  
    // Call: http://localhost:8080/vehicle
    $scope.submitVehicle = function() {
 
        var method = "";
        var url = "";
 
        if ($scope.vehicleForm.mfrId == -1) {
            method = "POST";
            url = '/vehicle';
        } else {
            method = "PUT";
            url = '/vehicle';
        }
 
        $http({
            method: method,
            url: url,
            data: angular.toJson($scope.vehicleForm),
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(_success, _error);
    };
 
    $scope.createVehicle = function() {
        _clearFormData();
    }
 
    // HTTP DELETE- delete employee by Id
    // Call: http://localhost:8080/employee/{empId}
   // $scope.deleteVehicle = function(employee) {
     //   $http({
       //     method: 'DELETE',
         //   url: '/vehicle/' + vehicle.empId
        //}).then(_success, _error);
   // };
 
    // In case of edit
    //$scope.editEmployee = function(employee) {
      //  $scope.employeeForm.empId = employee.empId;
        //$scope.employeeForm.empNo = employee.empNo;
       // $scope.employeeForm.empName = employee.empName;
    //};
 
    // Private Method  
    // HTTP GET- get all employees collection
    // Call: http://localhost:8080/employees
    function _refreshVechileData() {
        $http({
            method: 'GET',
            url: '/vehicles'
        }).then(
            function(res) { // success
                $scope.vehicles = res.data;
            },
            function(res) { // error
                console.log("Error: " + res.status + " : " + res.data);
            }
        );
    }
 
    function _success(res) {
        _refreshVehicleData();
        _clearFormData();
    }
 
    function _error(res) {
        var data = res.data;
        var status = res.status;
        var header = res.header;
        var config = res.config;
        alert("Error: " + status + ":" + data);
    }
 
    // Clear the form
    function _clearFormData() {
        $scope.vehicleForm.mfrId = -1;
        $scope.vehicleForm.mfrName = "";
        $scope.vehicleForm.city = ""
        	 $scope.vehicleForm.state = ""
        		 $scope.vehicleForm.country = ""
    };
});