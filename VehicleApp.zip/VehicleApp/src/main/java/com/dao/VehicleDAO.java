package com.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

import model.Vehicle;
import model.VehicleForm;
  
@Repository
public class VehicleDAO {
  
    private static final Map<Long, Vehicle> vecMap = new HashMap<Long, Vehicle>();
  
    static {
    	initVecs();
    }
  
    private static void initVecs() {
        Vehicle veh1 = new Vehicle(1L, "FORD", "Charlotte", "NC","US");
        Vehicle veh2 = new Vehicle(2L, "TATA", "Chicago", "IL","US");
        Vehicle veh3 = new Vehicle(3L, "NISSAN", "Newyork", "IL","US");
  
        vecMap.put(veh1.getMfrId(), veh1);
        vecMap.put(veh2.getMfrId(), veh2);
        vecMap.put(veh3.getMfrId(), veh3);
    }
  
    public Long getMaxMfrId() {
        Set<Long> keys = vecMap.keySet();
        Long max = 0L;
        for (Long key : keys) {
            if (key > max) {
                max = key;
            }
        }
        return max;
    }
  
    public Vehicle getVehicle(Long mfrId) {
        return vecMap.get(mfrId);
    }
  
    public Vehicle addVehicle(VehicleForm vehiForm) {
        Long mfrId= this.getMaxMfrId()+ 1;
        vehiForm.setMfrId(mfrId);
        Vehicle newVeh = new Vehicle(vehiForm);  
         
        vecMap.put(newVeh.getMfrId(), newVeh);
        return newVeh;
    }
  
	/*
	 * public Vehicle updateEmployee(VehicleForm empForm) { Vehicle emp =
	 * this.getEmployee(empForm.getEmpId()); if(emp!= null) {
	 * emp.setEmpNo(empForm.getEmpNo()); emp.setEmpName(empForm.getEmpName());
	 * emp.setPosition(empForm.getPosition()); } return emp; }
	 */
	/*
	 * public void deleteEmployee(Long empId) { empMap.remove(empId); }
	 */
  
    public List<Vehicle> getAllVehicles() {
        Collection<Vehicle> c = vecMap.values();
        List<Vehicle> list = new ArrayList<Vehicle>();
        list.addAll(c);
        return list;
    }
  
}
