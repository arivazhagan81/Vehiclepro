package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.VehicleDAO;

import model.Vehicle;
import model.VehicleForm;
  
@RestController 
public class MainRESTController {
  
    @Autowired
    private VehicleDAO vehicleDAO;
    // URL:
    // http://localhost:8080/SomeContextPath/vehicles
    // http://localhost:8080/SomeContextPath/vehicles.xml
    // http://localhost:8080/SomeContextPath/vehicles.json
    @RequestMapping(value = "/vehicle", method = RequestMethod.GET,produces = { MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public List<Vehicle> getVehicles() {
        List<Vehicle> list = vehicleDAO.getAllVehicles();
        return list;
    }
  
    // URL:
    // http://localhost:8080/SomeContextPath/vehicle/{mfrId}
    // http://localhost:8080/SomeContextPath/vehicle/{mfrId}.xml
    // http://localhost:8080/SomeContextPath/vehicle/{mfrId}.json
    @RequestMapping(value = "/vehicles/{mfrId}", method = RequestMethod.GET,produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public Vehicle getVehicle(@PathVariable("mfrId") Long mfrId) {
        return vehicleDAO.getVehicle(mfrId);
    }
  
    // URL:
    // http://localhost:8080/SomeContextPath/vehicle
    // http://localhost:8080/SomeContextPath/vehicle.xml
    // http://localhost:8080/SomeContextPath/vehicle.json
  
    @RequestMapping(value = "/vehicle", //
            method = RequestMethod.POST, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public Vehicle addVehicle(@RequestBody VehicleForm vehForm) {
  
        System.out.println("(Service Side) Creating vehicle with empNo: " + vehForm.getMfrId());
  
        return vehicleDAO.addVehicle(vehForm);
    }
  
    // URL:
    // http://localhost:8080/SomeContextPath/vehicle
    // http://localhost:8080/SomeContextPath/vehicle.xml
    // http://localhost:8080/SomeContextPath/vehicle.json
 //   @RequestMapping(value = "/vehicle", //
   //         method = RequestMethod.PUT, //
     //       produces = { MediaType.APPLICATION_JSON_VALUE, //
       //             MediaType.APPLICATION_XML_VALUE })
  /*  @ResponseBody
    public Vehicle updateEmployee(@RequestBody VehicleForm vehForm) {
  
        System.out.println("(Service Side) Editing employee with Id: " + vehForm.getMfrId());
  
        return vehicleDAO.updateEmployee(vehForm);
    }
  
    // URL:
    // http://localhost:8080/SomeContextPath/employee/{empId}
    @RequestMapping(value = "/employee/{empId}", //
            method = RequestMethod.DELETE, //
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public void deleteEmployee(@PathVariable("empId") Long empId) {
  
        System.out.println("(Service Side) Deleting employee with Id: " + empId);
  
        vehicleDAO.deleteEmployee(empId);
    }
  */
}