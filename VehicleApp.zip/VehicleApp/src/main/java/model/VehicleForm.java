package model;

public class VehicleForm {
    
	private Long mfrId;
    private String mfrName;
    private String city;
    private String state;
    private String country;
	public Long getMfrId() {
		return mfrId;
	}
	public void setMfrId(Long mfrId) {
		this.mfrId = mfrId;
	}
	public String getMfrName() {
		return mfrName;
	}
	public void setMfrName(String mfrName) {
		this.mfrName = mfrName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
    
    
    
 
 }
