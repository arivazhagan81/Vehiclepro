package model;

public class Vehicle {
	 
    private Long mfrId;
    private String mfrName;
    private String city;
    private String state;
    private String country;
 
    public Vehicle() {
 
    }
 
    public Vehicle(VehicleForm vecForm) {
        this.mfrId = vecForm.getMfrId();
        this.mfrName = vecForm.getMfrName();
        this.city = vecForm.getCity();
        this.state = vecForm.getState();
        this.country = vecForm.getCountry();
    }
 
    public Vehicle(Long mfrId, String mfrName, String city, String state, String country) {
        this.mfrId = mfrId;
        this.mfrName = mfrName;
        this.city = city;
        this.state = state;
        this.state = country;
    }

	public Long getMfrId() {
		return mfrId;
	}

	public void setMfrId(Long mfrId) {
		this.mfrId = mfrId;
	}

	public String getMfrName() {
		return mfrName;
	}

	public void setMfrName(String mfrName) {
		this.mfrName = mfrName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
 
     
}
